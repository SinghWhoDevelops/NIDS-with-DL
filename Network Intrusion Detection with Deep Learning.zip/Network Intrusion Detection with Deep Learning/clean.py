"""Step 3a: Data cleaning for CIC-IDS2017 (eda.py ke findings ke basis pe).

Input : data/interim/cicids2017_merged.parquet  (eda.py ne banayi thi)
Output: data/interim/cicids2017_clean.parquet
"""
import numpy as np
import pandas as pd

SRC = "data/interim/cicids2017_merged.parquet"
DST = "data/interim/cicids2017_clean.parquet"
DROPPED_TXT = "data/interim/dropped_columns.txt"

CORR_THRESHOLD = 0.99  # isse zyada match karne wale columns ki copy hataayenge
KEEP_NEGATIVE = ["Init Fwd Win Bytes", "Init Bwd Win Bytes"]  # inme -1 placeholder hota hai

df = pd.read_parquet(SRC)
df.columns = df.columns.str.strip()
print("Start shape:", df.shape)

# ---------- 1. Label ke naam saaf karo (toota hua dash '�' hatao) ----------
df["Label"] = df["Label"].str.replace(r"[^\x00-\x7F]", "-", regex=True).str.strip()
raw_counts = df["Label"].value_counts()

# ---------- 2. Duplicate rows hatao ----------
before = len(df)
df = df.drop_duplicates().reset_index(drop=True)
print(f"\n[2] Duplicates hataye: {before - len(df):,} rows  -> shape {df.shape}")

# ---------- 3. Galat negative values wali rows hatao ----------
feat_cols = [c for c in df.columns if c != "Label"]
check_cols = [c for c in feat_cols if c not in KEEP_NEGATIVE]
bad_rows = (df[check_cols] < 0).any(axis=1)
print(f"[3] Negative-value rows hataye: {int(bad_rows.sum()):,}")
df = df.loc[~bad_rows].reset_index(drop=True)

# ---------- 4. Constant columns hatao (sab rows mein same value) ----------
feat_cols = [c for c in df.columns if c != "Label"]
const_cols = [c for c in feat_cols if df[c].nunique() <= 1]
df = df.drop(columns=const_cols)
print(f"[4] Constant columns hataye ({len(const_cols)}): {const_cols}")

# ---------- 5. Copy jaise (highly correlated) columns hatao ----------
feat_cols = [c for c in df.columns if c != "Label"]
sample = df[feat_cols].sample(n=min(200_000, len(df)), random_state=42)
corr = sample.corr().abs()
upper = corr.where(np.triu(np.ones(corr.shape, dtype=bool), k=1))
corr_cols = [c for c in upper.columns if (upper[c] > CORR_THRESHOLD).any()]
df = df.drop(columns=corr_cols)
print(f"[5] Correlated columns hataye ({len(corr_cols)}): {corr_cols}")

# ---------- Summary ----------
summary = pd.DataFrame(
    {"raw": raw_counts, "clean": df["Label"].value_counts()}
).fillna(0).astype(int)
summary["lost"] = summary["raw"] - summary["clean"]
print("\nClass-wise rows (raw vs clean):")
print(summary.sort_values("raw", ascending=False))

print("\nFinal shape:", df.shape, "| Final features:", df.shape[1] - 1)

# ---------- Save ----------
df.to_parquet(DST)
with open(DROPPED_TXT, "w") as f:
    f.write("Constant:\n" + "\n".join(const_cols))
    f.write("\n\nCorrelated:\n" + "\n".join(corr_cols))
print(f"\nSaved: {DST}")

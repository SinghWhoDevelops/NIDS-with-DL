"""Step 6: IDS ki robustness - FGSM / PGD attack aur adversarial training (defense).

Sawal: agar attacker apne attack traffic ke features thode badle, to kya MLP use "Benign" samajh lega?

Threat model (simple):
  - White-box: attacker ko model ke gradients pata hain (worst case).
  - Sirf ATTACK rows perturb hoti hain; Benign traffic jaisa hai waisa rehta hai.
  - eps ka matlab: har feature maximum itne "standard deviation" hil sakta hai
    (data scaled hai, to eps=0.1 ka matlab 0.1 std).
  - Perturbed value train data ki min/max range ke andar clip hoti hai.
  - Do "(no value)" flag features ko perturb nahi karte (wo 0/1 hain).

Dhyan: ye FEATURE-SPACE test hai. Asli network traffic mein features aapas mein jude hote hain
(packets, bytes, time), to asli attacker ke liye ye utna aasan nahi. Isliye ise "worst-case
robustness test" kaho, "real-world exploit" nahi.

Input : data/processed/, models/mlp_best.pt (Step 5 ka 13-class MLP)
Output: models/mlp_advtrained.pt, reports/fgsm_results.csv,
        reports/figures/fgsm_robustness.png
"""
import json
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import f1_score

D = "data/processed"
FIG = "reports/figures"
SEED = 42
EPS_LIST = [0.0, 0.05, 0.1, 0.2, 0.3, 0.5, 1.0]
EPS_TRAIN = 0.2          # defense training mein attack ki maximum taakat
PGD_STEPS = 10           # PGD = FGSM ka 10-step, zyada taakatwar version
EPOCHS, BATCH, LR = 25, 2048, 1e-3
ORIG_TEST_F1 = 0.8029    # train_mlp.py mein test macro-F1 (sanity check ke liye)

os.makedirs(FIG, exist_ok=True)
os.makedirs("reports", exist_ok=True)
os.makedirs("models", exist_ok=True)
assert os.path.exists("models/mlp_best.pt"), "models/mlp_best.pt nahi mila (train_mlp.py pehle chalani hai)"

torch.manual_seed(SEED)
np.random.seed(SEED)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device)

# ---------- 1. Data ----------
Xt = torch.from_numpy(np.load(f"{D}/X_train.npy"))
yt = torch.from_numpy(np.load(f"{D}/y_train.npy"))
Xv = torch.from_numpy(np.load(f"{D}/X_val.npy"))
yv_np = np.load(f"{D}/y_val.npy")
yv = torch.from_numpy(yv_np)
Xe = torch.from_numpy(np.load(f"{D}/X_test.npy"))
ye_np = np.load(f"{D}/y_test.npy")
ye = torch.from_numpy(ye_np)

with open(f"{D}/label_map.json") as f:
    n_classes = len(json.load(f))
with open(f"{D}/feature_names.json") as f:
    feature_names = json.load(f)
n_features = Xt.shape[1]

# kaun se features perturb ho sakte hain, aur unki allowed range
mask = torch.tensor([0.0 if "(no value)" in n else 1.0 for n in feature_names], device=device)
lo = Xt.min(0).values.to(device)
hi = Xt.max(0).values.to(device)
print(f"Test attack rows: {int((ye_np != 0).sum()):,} | perturb hone wale features: {int(mask.sum())}/{n_features}")


# ---------- 2. Model ----------
def build():
    def block(i, o, p):
        return [nn.Linear(i, o), nn.BatchNorm1d(o), nn.ReLU(), nn.Dropout(p)]

    return nn.Sequential(
        *block(n_features, 256, 0.2), *block(256, 128, 0.2), *block(128, 64, 0.1),
        nn.Linear(64, n_classes),
    ).to(device)


def predict(model, X, bs=65536):
    model.eval()
    out = []
    with torch.no_grad():
        for i in range(0, len(X), bs):
            out.append(model(X[i:i + bs].to(device)).argmax(1).cpu())
    return torch.cat(out).numpy()


# ---------- 3. Attack (steps=1 -> FGSM, steps>1 -> PGD) ----------
def attack(model, x, y, eps, steps):
    """x ko is tarah badlo ki model ka loss badh jaye. Model eval mode mein hona chahiye."""
    eps = torch.as_tensor(eps, dtype=torch.float32, device=x.device)
    x0 = x.detach()
    xa = x0.clone()
    alpha = eps if steps == 1 else 2.5 * eps / steps
    for _ in range(steps):
        xa.requires_grad_(True)
        loss = F.cross_entropy(model(xa), y, reduction="sum")
        (g,) = torch.autograd.grad(loss, xa)
        xa = xa.detach() + alpha * g.sign() * mask
        delta = torch.max(torch.min(xa - x0, eps), -eps)   # eps ke andar rakho
        xa = torch.max(torch.min(x0 + delta, hi), lo)      # data ki range ke andar rakho
    return xa.detach()


def perturb_attack_rows(model, X, y, eps, steps, bs=8192):
    """Sirf attack rows (y != 0) badalti hain, Benign rows jaisi ki taisi."""
    model.eval()
    Xa = X.clone()
    idx = torch.nonzero(y != 0).squeeze(1)
    for i in range(0, len(idx), bs):
        j = idx[i:i + bs]
        Xa[j] = attack(model, X[j].to(device), y[j].to(device), eps, steps).cpu()
    return Xa


def robust_eval(model, X, y, y_np, eps, steps):
    """(macro-F1, detection rate). Detection rate = attacks mein se kitne 'Benign' nahi bole gaye."""
    Xa = X if eps == 0 else perturb_attack_rows(model, X, y, eps, steps)
    pred = predict(model, Xa)
    atk = y_np != 0
    return f1_score(y_np, pred, average="macro", zero_division=0), float((pred[atk] != 0).mean())


# ---------- 4. Original MLP pe attack ----------
orig = build()
orig.load_state_dict(torch.load("models/mlp_best.pt", map_location=device))
orig.eval()

rows = []


def run_attacks(model, name):
    for steps, atk_name in [(1, "FGSM"), (PGD_STEPS, f"PGD-{PGD_STEPS}")]:
        for eps in EPS_LIST:
            f1, det = robust_eval(model, Xe, ye, ye_np, eps, steps)
            rows.append({"model": name, "attack": atk_name, "eps": eps,
                         "macro_f1": f1, "detection": det})
            print(f"{name:14s} {atk_name:7s} eps={eps:<5} macro-F1 {f1:.4f} | attacks pakde {det:.4f}")


print("\n=== Original MLP pe attack ===")
t0 = time.time()
run_attacks(orig, "Original")
clean_f1 = rows[0]["macro_f1"]
print(f"\nSanity check: eps=0 pe macro-F1 = {clean_f1:.4f} (train_mlp.py mein {ORIG_TEST_F1} aaya tha, "
      "thoda sa fark chalta hai)")
print(f"Time: {(time.time() - t0) / 60:.1f} min")

# ---------- 5. Defense: adversarial training ----------
print("\n=== Adversarial training (defense) ===")
robust = build()
counts = torch.bincount(yt, minlength=n_classes).float()
weights = (counts.sum() / counts) ** 0.5
weights = weights * counts.sum() / (weights * counts).sum()
criterion = nn.CrossEntropyLoss(weight=weights.to(device))
optimizer = torch.optim.Adam(robust.parameters(), lr=LR)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=0.5, patience=2)

best_score, best_epoch = -1.0, 0
print("Epoch | train loss | val clean F1 | val adv F1 | score | time")
for epoch in range(1, EPOCHS + 1):
    t0 = time.time()
    perm = torch.randperm(len(Xt))
    total = torch.zeros((), device=device)
    for i in range(0, len(perm), BATCH):
        idx = perm[i:i + BATCH]
        if len(idx) < 2:
            continue
        xb, yb = Xt[idx].to(device), yt[idx].to(device)

        # attack examples banao (model eval mode mein, taaki BatchNorm na bigde)
        robust.eval()
        eps_b = torch.rand(len(idx), 1, device=device) * EPS_TRAIN
        xadv = attack(robust, xb, yb, eps_b, 1)
        xadv = torch.where((yb != 0).unsqueeze(1), xadv, xb)  # Benign rows ko mat chhedo

        # clean + adversarial dono pe seekho
        robust.train()
        optimizer.zero_grad()
        loss = criterion(robust(torch.cat([xb, xadv])), torch.cat([yb, yb]))
        loss.backward()
        optimizer.step()
        total += loss.detach() * len(idx)

    clean_v = f1_score(yv_np, predict(robust, Xv), average="macro", zero_division=0)
    adv_v, _ = robust_eval(robust, Xv, yv, yv_np, EPS_TRAIN, 1)
    score = (clean_v + adv_v) / 2  # best epoch validation pe chuna jata hai, test pe nahi
    scheduler.step(score)
    mark = ""
    if score > best_score:
        best_score, best_epoch = score, epoch
        torch.save(robust.state_dict(), "models/mlp_advtrained.pt")
        mark = "  <- best"
    print(f"{epoch:5d} | {total.item() / len(Xt):10.4f} | {clean_v:12.4f} | {adv_v:10.4f} | "
          f"{score:.4f} | {time.time() - t0:3.0f}s{mark}")

print(f"\nBest epoch: {best_epoch} (score {best_score:.4f})")
robust.load_state_dict(torch.load("models/mlp_advtrained.pt", map_location=device))

# ---------- 6. Defended MLP pe wahi attacks ----------
print("\n=== Adversarially-trained MLP pe attack ===")
run_attacks(robust, "AdvTrained")

# ---------- 7. Results ----------
res = pd.DataFrame(rows)
res.to_csv("reports/fgsm_results.csv", index=False)

for metric, title in [("detection", "Attacks pakde gaye (detection rate)"), ("macro_f1", "Test macro-F1")]:
    print(f"\n----- {title} -----")
    print(res.pivot_table(index=["attack", "eps"], columns="model", values=metric).round(4).to_string())

fig, axes = plt.subplots(1, 2, figsize=(14, 5))
for (m, a), g in res.groupby(["model", "attack"]):
    style = "-" if a == "FGSM" else "--"
    axes[0].plot(g["eps"], g["detection"], style, marker="o", label=f"{m} / {a}")
    axes[1].plot(g["eps"], g["macro_f1"], style, marker="o", label=f"{m} / {a}")
axes[0].set_title("Detection rate vs attack strength")
axes[0].set_ylabel("Attacks mein se kitne pakde gaye")
axes[1].set_title("Macro-F1 vs attack strength")
axes[1].set_ylabel("Test macro-F1")
for ax in axes:
    ax.set_xlabel("eps (std units mein)")
    ax.grid(alpha=0.3)
    ax.legend()
plt.tight_layout()
plt.savefig(f"{FIG}/fgsm_robustness.png", dpi=150)
plt.close()

print("\nSaved: models/mlp_advtrained.pt, reports/fgsm_results.csv, reports/figures/fgsm_robustness.png")

"""Step 7: Kaun se features model ke liye important hain? (explainability)

Method: Permutation importance (model-agnostic, koi extra library install nahi karni).
  - Ek feature ke values ko randomly mix kar do (uska jawab-se-rishta toot jata hai).
  - Agar model ka macro-F1 bahut gir jaye, to wo feature important tha.
  - Importance = (original macro-F1) - (mix karne ke baad macro-F1). Zyada = zyada important.

MLP aur Random Forest dono pe SAME tareeke se nikalte hain, taaki comparison fair rahe.
Validation data use hota hai (test nahi), aur har class se max CAP_PER_CLASS rows li jati hain
taaki chhoti attack classes bhi score mein dikhein.

Dhyan: jo features aapas mein bahut milte-julte hain, unki importance aapas mein baant jati hai,
to ek feature ka kam score "bekaar feature" nahi, "uska doosra saathi kaam kar raha hai" bhi ho sakta hai.

Input : data/processed/, models/mlp_best.pt
Output: reports/feature_importance.csv, reports/figures/feature_importance.png
"""
import json
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score

D = "data/processed"
FIG = "reports/figures"
SEED = 42
CAP_PER_CLASS = 5000
REPEATS = 3
TOP = 15

os.makedirs(FIG, exist_ok=True)
os.makedirs("reports", exist_ok=True)
assert os.path.exists("models/mlp_best.pt"), "models/mlp_best.pt nahi mila"

rng = np.random.default_rng(SEED)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---------- 1. Data ----------
X_tr, y_tr = np.load(f"{D}/X_train.npy"), np.load(f"{D}/y_train.npy")
X_val, y_val = np.load(f"{D}/X_val.npy"), np.load(f"{D}/y_val.npy")
with open(f"{D}/feature_names.json") as f:
    feature_names = [n.strip() for n in json.load(f)]
with open(f"{D}/label_map.json") as f:
    n_classes = len(json.load(f))
n_features = X_tr.shape[1]

# validation se class-wise subsample
keep = []
for c in np.unique(y_val):
    idx = np.where(y_val == c)[0]
    if len(idx) > CAP_PER_CLASS:
        idx = rng.choice(idx, CAP_PER_CLASS, replace=False)
    keep.append(idx)
keep = np.concatenate(keep)
Xs, ys = X_val[keep], y_val[keep]
print(f"Importance ke liye rows: {len(Xs):,} (har class se max {CAP_PER_CLASS})")


# ---------- 2. Models ----------
def block(i, o, p):
    return [nn.Linear(i, o), nn.BatchNorm1d(o), nn.ReLU(), nn.Dropout(p)]


mlp = nn.Sequential(
    *block(n_features, 256, 0.2), *block(256, 128, 0.2), *block(128, 64, 0.1),
    nn.Linear(64, n_classes),
).to(device)
mlp.load_state_dict(torch.load("models/mlp_best.pt", map_location=device))
mlp.eval()


def mlp_predict(X):
    out = []
    xt = torch.from_numpy(X)
    with torch.no_grad():
        for i in range(0, len(xt), 65536):
            out.append(mlp(xt[i:i + 65536].to(device)).argmax(1).cpu())
    return torch.cat(out).numpy()


print("\nRandom Forest dobara train ho raha hai (~3 min, wahi settings jo Step 4 mein thi)...")
t0 = time.time()
rf = RandomForestClassifier(n_estimators=100, n_jobs=-1, random_state=SEED)
rf.fit(X_tr, y_tr)
print(f"RF ready ({(time.time() - t0) / 60:.1f} min)")


# ---------- 3. Permutation importance ----------
def perm_importance(predict, name):
    base = f1_score(ys, predict(Xs), average="macro", zero_division=0)
    drops = np.zeros((n_features, REPEATS))
    t0 = time.time()
    for j in range(n_features):
        for r in range(REPEATS):
            Xp = Xs.copy()
            Xp[:, j] = rng.permutation(Xp[:, j])
            drops[j, r] = base - f1_score(ys, predict(Xp), average="macro", zero_division=0)
        if (j + 1) % 10 == 0:
            print(f"  {name}: {j + 1}/{n_features} features ho gaye ({(time.time() - t0) / 60:.1f} min)")
    print(f"{name}: subsample pe macro-F1 = {base:.4f}")
    return pd.DataFrame({f"{name}_drop": drops.mean(1), f"{name}_std": drops.std(1)}, index=feature_names)


print("\nMLP ke liye permutation importance...")
imp_mlp = perm_importance(mlp_predict, "mlp")
print("\nRandom Forest ke liye permutation importance...")
imp_rf = perm_importance(rf.predict, "rf")

df = imp_mlp.join(imp_rf)
df.to_csv("reports/feature_importance.csv", index_label="feature")

# ---------- 4. Results ----------
for name in ["mlp", "rf"]:
    print(f"\n===== Top {TOP} features: {name.upper()} (macro-F1 kitna girta hai) =====")
    top = df.sort_values(f"{name}_drop", ascending=False).head(TOP)
    print(top[[f"{name}_drop", f"{name}_std"]].round(4).to_string())

top_mlp = set(df["mlp_drop"].nlargest(TOP).index)
top_rf = set(df["rf_drop"].nlargest(TOP).index)
common = sorted(top_mlp & top_rf)
rank_corr = df["mlp_drop"].corr(df["rf_drop"], method="spearman")
print(f"\nDono ke Top {TOP} mein common features: {len(common)}/{TOP}")
print(common)
print(f"Poore 59 features pe rank correlation (Spearman): {rank_corr:.3f}  (1 = bilkul same order)")

# ---------- 5. Graph ----------
fig, axes = plt.subplots(1, 2, figsize=(15, 6))
for ax, name, title in [(axes[0], "mlp", "MLP"), (axes[1], "rf", "Random Forest")]:
    top = df.sort_values(f"{name}_drop", ascending=False).head(TOP).iloc[::-1]
    ax.barh(top.index, top[f"{name}_drop"], xerr=top[f"{name}_std"], color="#2b6cb0")
    ax.set_title(f"{title} - Top {TOP} features")
    ax.set_xlabel("Feature mix karne par macro-F1 mein girawat")
    ax.grid(axis="x", alpha=0.3)
plt.tight_layout()
plt.savefig(f"{FIG}/feature_importance.png", dpi=150)
plt.close()

print("\nSaved: reports/feature_importance.csv, reports/figures/feature_importance.png")

"""Step 2: EDA for CIC-IDS2017 (MachineLearningCSV files in data/raw/)."""
import glob
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

RAW_DIR = "data/raw"
FIG_DIR = "reports/figures"
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs("data/interim", exist_ok=True)

# ---------- 1. Load + merge ----------
parquet_files = sorted(glob.glob(f"{RAW_DIR}/*.parquet"))
csv_files = sorted(glob.glob(f"{RAW_DIR}/*.csv"))
assert parquet_files or csv_files, f"{RAW_DIR}/ mein koi parquet/CSV file nahi mili"

if parquet_files:
    frames = [pd.read_parquet(f) for f in parquet_files]
else:
    # latin1: web-attack labels mein special dash character hota hai
    frames = [pd.read_csv(f, encoding="latin1", low_memory=False) for f in csv_files]

df = pd.concat(frames, ignore_index=True)
df.columns = df.columns.str.strip()  # column names mein leading spaces ho sakte hain

# label column ka naam alag ho sakta hai, usse "Label" bana do
label_cols = [c for c in df.columns if c.lower() == "label"]
if not label_cols:
    raise SystemExit(f"Label column nahi mila. Columns ye hain:\n{list(df.columns)}")
df = df.rename(columns={label_cols[0]: "Label"})

print("Files loaded:", len(parquet_files) or len(csv_files))
print("Shape:", df.shape)
print("\nDtypes:\n", df.dtypes.value_counts())

# fast reload ke liye merged copy save
df.to_parquet("data/interim/cicids2017_merged.parquet")

# ---------- 2. Class distribution ----------
counts = df["Label"].value_counts()
print("\nClass counts:\n", counts)
print("\nClass %:\n", (counts / len(df) * 100).round(4))

plt.figure(figsize=(10, 5))
sns.barplot(x=counts.values, y=counts.index, orient="h")
plt.xscale("log")
plt.xlabel("Samples (log scale)")
plt.title("CIC-IDS2017 class distribution")
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/class_distribution.png", dpi=150)
plt.close()

# ---------- 3. Missing / Inf values ----------
feat = df.drop(columns="Label").select_dtypes("number")
inf_per_col = np.isinf(feat).sum()
nan_per_col = feat.isna().sum()
print("\nTotal inf:", int(inf_per_col.sum()), "| Total NaN:", int(nan_per_col.sum()))
print("Columns with inf:\n", inf_per_col[inf_per_col > 0])
print("Columns with NaN:\n", nan_per_col[nan_per_col > 0])

# ---------- 4. Duplicates + useless columns ----------
print("\nDuplicate rows:", int(df.duplicated().sum()))

constant_cols = [c for c in feat.columns if feat[c].nunique() <= 1]
print("Constant columns:", constant_cols)

dup_named = [c for c in df.columns if c.endswith(".1")]
print("Duplicate-named columns:", dup_named)

# ---------- 5. Negative values (kuch features mein negative nahi hone chahiye) ----------
neg = (feat < 0).sum()
print("\nColumns with negative values:\n", neg[neg > 0])

# ---------- 6. Correlation (sample pe, taaki fast rahe) ----------
sample = feat.replace([np.inf, -np.inf], np.nan).dropna().sample(
    n=min(100_000, len(feat)), random_state=42
)
corr = sample.drop(columns=constant_cols, errors="ignore").corr()

plt.figure(figsize=(14, 12))
sns.heatmap(corr, cmap="coolwarm", center=0, xticklabels=False, yticklabels=False)
plt.title("Feature correlation (100k sample)")
plt.tight_layout()
plt.savefig(f"{FIG_DIR}/correlation_heatmap.png", dpi=150)
plt.close()

high = (
    corr.where(np.triu(np.ones(corr.shape, dtype=bool), k=1))
    .stack()
    .loc[lambda s: s.abs() > 0.95]
)
print(f"\nHighly correlated pairs (|r| > 0.95): {len(high)}")
print(high.sort_values(key=abs, ascending=False).head(15))

print(f"\nFigures saved in {FIG_DIR}/")

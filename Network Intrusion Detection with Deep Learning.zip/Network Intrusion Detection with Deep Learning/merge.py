"""Extra experiment: 'Web Attack - Brute Force' + 'Web Attack - XSS' -> ek class 'Web Attack' (12 classes).

13-class wale results MAIN benchmark rehte hain. Ye script unhe chhuti nahi,
sab kuch alag naam se save karti hai (rf12_*, mlp12_*, merge_experiment_report.txt).

Features (X) same hain, sirf labels badalte hain, isliye scaling dobara nahi karni padti.
Settings (seed, trees, epochs, architecture) 13-class wale runs ke jaisi hi hain, taaki comparison fair rahe.
"""
import json
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
)

D = "data/processed"
FIG = "reports/figures"
SEED = 42
MERGE = ["Web Attack - Brute Force", "Web Attack - XSS"]
MERGED_NAME = "Web Attack"

# 13-class runs ke numbers (Step 4 aur Step 5 ke output se)
PREV = {
    "RF  (13-class)": {"classes": 13, "macro": 0.8585, "unchanged": 0.9151},
    "MLP (13-class)": {"classes": 13, "macro": 0.8029, "unchanged": 0.8781},
}

os.makedirs(FIG, exist_ok=True)
os.makedirs("models", exist_ok=True)
os.makedirs("reports", exist_ok=True)

# ---------- 1. Labels merge karo ----------
X_tr, X_val, X_te = (np.load(f"{D}/X_{s}.npy") for s in ("train", "val", "test"))
y_tr_old, y_val_old, y_te_old = (np.load(f"{D}/y_{s}.npy") for s in ("train", "val", "test"))
with open(f"{D}/label_map.json") as f:
    label_map = json.load(f)

assert all(m in label_map for m in MERGE), f"Ye labels nahi mile: {MERGE}"


def new_name(n):
    return MERGED_NAME if n in MERGE else n


names = ["Benign"] + sorted({new_name(n) for n in label_map if n != "Benign"})
new_map = {n: i for i, n in enumerate(names)}
old_to_new = np.zeros(len(label_map), dtype=np.int64)
for n, i in label_map.items():
    old_to_new[i] = new_map[new_name(n)]

y_tr, y_val, y_te = old_to_new[y_tr_old], old_to_new[y_val_old], old_to_new[y_te_old]
with open(f"{D}/label_map_12class.json", "w") as f:
    json.dump(new_map, f, indent=2)

print(f"Classes: {len(names)}")
print(pd.DataFrame(
    {s: pd.Series(y).value_counts().sort_index()
     for s, y in [("train", y_tr), ("val", y_val), ("test", y_te)]}
).rename(index=dict(enumerate(names))))

results = {}
report_lines = []


def save_report():
    with open("reports/merge_experiment_report.txt", "w", encoding="utf-8") as fh:
        fh.write("\n".join(report_lines))


def evaluate(tag, fig_name, pred):
    """Test pe score nikalo, confusion matrix save karo."""
    macro = f1_score(y_te, pred, average="macro")
    per_class = f1_score(y_te, pred, average=None, labels=list(range(len(names))))
    unchanged = float(np.mean([f for n, f in zip(names, per_class) if n != MERGED_NAME]))
    acc = float((pred == y_te).mean())
    rep = classification_report(y_te, pred, target_names=names, digits=4, zero_division=0)
    p, r, f1b, _ = precision_recall_fscore_support(
        (y_te != 0).astype(int), (pred != 0).astype(int), average="binary", zero_division=0
    )
    print(f"\n===== {tag} =====")
    print(f"Test macro-F1 (12 class)       : {macro:.4f}")
    print(f"Macro-F1 (baaki 11 same class) : {unchanged:.4f}")
    print(f"Test accuracy                  : {acc:.4f}")
    print(rep)
    print(f"Attack detect karna -> precision {p:.4f} | recall {r:.4f} | F1 {f1b:.4f}")

    cm = confusion_matrix(y_te, pred, normalize="true")
    plt.figure(figsize=(11, 9))
    sns.heatmap(cm, annot=True, fmt=".2f", xticklabels=names, yticklabels=names,
                cmap="Blues", cbar=False)
    plt.xlabel("Model ne kya bola")
    plt.ylabel("Asli class")
    plt.title(f"{tag} - confusion matrix (test, row-normalized)")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(f"{FIG}/{fig_name}", dpi=150)
    plt.close()

    report_lines.extend([
        f"===== {tag} =====",
        f"Test macro-F1: {macro:.4f} | unchanged-11 macro-F1: {unchanged:.4f} | accuracy: {acc:.4f}",
        f"Attack-vs-benign: precision {p:.4f}, recall {r:.4f}, F1 {f1b:.4f}",
        rep, "",
    ])
    save_report()
    results[tag] = {"classes": len(names), "macro": macro, "unchanged": unchanged}


# ---------- 2. Random Forest (12 class) ----------
print("\nRandom Forest train ho raha hai (~3 min)...")
t0 = time.time()
rf = RandomForestClassifier(n_estimators=100, n_jobs=-1, random_state=SEED)
rf.fit(X_tr, y_tr)
print(f"RF training time: {(time.time() - t0) / 60:.1f} min")
evaluate("RF  (12-class)", "rf12_confusion_matrix.png", rf.predict(X_te))
del rf


# ---------- 3. MLP (12 class) ----------
def run_mlp():
    import torch
    import torch.nn as nn

    EPOCHS, BATCH, LR = 25, 2048, 1e-3
    torch.manual_seed(SEED)
    np.random.seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("\nMLP device:", device)

    Xt, yt = torch.from_numpy(X_tr), torch.from_numpy(y_tr)
    Xv, Xe = torch.from_numpy(X_val), torch.from_numpy(X_te)
    n_classes = len(names)

    counts = torch.bincount(yt, minlength=n_classes).float()
    weights = (counts.sum() / counts) ** 0.5
    weights = weights * counts.sum() / (weights * counts).sum()

    def block(i, o, p):
        return [nn.Linear(i, o), nn.BatchNorm1d(o), nn.ReLU(), nn.Dropout(p)]

    model = nn.Sequential(
        *block(Xt.shape[1], 256, 0.2), *block(256, 128, 0.2), *block(128, 64, 0.1),
        nn.Linear(64, n_classes),
    ).to(device)
    criterion = nn.CrossEntropyLoss(weight=weights.to(device))
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=0.5, patience=2)

    def predict(X, bs=65536):
        model.eval()
        out = []
        with torch.no_grad():
            for i in range(0, len(X), bs):
                out.append(model(X[i:i + bs].to(device)).argmax(1).cpu())
        return torch.cat(out).numpy()

    best_f1, best_epoch = -1.0, 0
    print("Epoch | train loss | val macro-F1")
    for epoch in range(1, EPOCHS + 1):
        model.train()
        perm = torch.randperm(len(Xt))
        total = torch.zeros((), device=device)
        for i in range(0, len(perm), BATCH):
            idx = perm[i:i + BATCH]
            if len(idx) < 2:
                continue
            xb, yb = Xt[idx].to(device), yt[idx].to(device)
            optimizer.zero_grad()
            loss = criterion(model(xb), yb)
            loss.backward()
            optimizer.step()
            total += loss.detach() * len(idx)
        val_f1 = f1_score(y_val, predict(Xv), average="macro")
        scheduler.step(val_f1)
        mark = ""
        if val_f1 > best_f1:
            best_f1, best_epoch = val_f1, epoch
            torch.save(model.state_dict(), "models/mlp12_best.pt")
            mark = "  <- best"
        print(f"{epoch:5d} | {total.item() / len(Xt):10.4f} | {val_f1:12.4f}{mark}")

    print(f"Best val macro-F1: {best_f1:.4f} (epoch {best_epoch})")
    model.load_state_dict(torch.load("models/mlp12_best.pt", map_location=device))
    return predict(Xe)


try:
    pred_mlp = run_mlp()
    evaluate("MLP (12-class)", "mlp12_confusion_matrix.png", pred_mlp)
except Exception as e:  # jaise PyTorch ka Windows security block
    print(f"\nMLP nahi chal paya: {e}\n(RF ke results save ho chuke hain.)")

# ---------- 4. Final comparison ----------
table = pd.DataFrame({**PREV, **results}).T
table.columns = ["classes", "macro-F1", "baaki 11 classes ka macro-F1"]
table["classes"] = table["classes"].astype(int)
print("\n===== Final comparison (test) =====")
print(table.round(4).to_string())
print("\nDhyan: 13-class aur 12-class ka 'macro-F1' seedha barabar nahi hai (12 wala aasan problem hai).")
print("Fair comparison ke liye 'baaki 11 classes' wala column dekho, jo dono mein same classes pe hai.")

report_lines.extend(["===== Final comparison (test) =====", table.round(4).to_string()])
save_report()
print("\nSaved: reports/merge_experiment_report.txt, reports/figures/rf12_confusion_matrix.png,"
      " reports/figures/mlp12_confusion_matrix.png, models/mlp12_best.pt")

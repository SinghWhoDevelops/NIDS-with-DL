"""Step 5: Deep learning model (MLP) in PyTorch.

Input : data/processed/ (prepare.py ka output)
Output: models/mlp_best.pt, reports/mlp_report.txt, reports/figures/mlp_confusion_matrix.png
"""
import json
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
import torch.nn as nn
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
)

D = "data/processed"
FIG = "reports/figures"
SEED = 42
EPOCHS = 25
BATCH = 2048
LR = 1e-3
RF_TEST_F1 = 0.8585  # Step 4 ka Random Forest score (isse compare karenge)

os.makedirs(FIG, exist_ok=True)
os.makedirs("models", exist_ok=True)
os.makedirs("reports", exist_ok=True)

torch.manual_seed(SEED)
np.random.seed(SEED)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device)

# ---------- 1. Data load ----------
X_tr = torch.from_numpy(np.load(f"{D}/X_train.npy"))
y_tr = torch.from_numpy(np.load(f"{D}/y_train.npy"))
X_val = torch.from_numpy(np.load(f"{D}/X_val.npy"))
y_val_np = np.load(f"{D}/y_val.npy")
X_te = torch.from_numpy(np.load(f"{D}/X_test.npy"))
y_te_np = np.load(f"{D}/y_test.npy")

with open(f"{D}/label_map.json") as f:
    label_map = json.load(f)
names = [k for k, _ in sorted(label_map.items(), key=lambda kv: kv[1])]
n_features, n_classes = X_tr.shape[1], len(names)
print(f"Train {tuple(X_tr.shape)} | Val {tuple(X_val.shape)} | Test {tuple(X_te.shape)}")

# ---------- 2. Class weights (chhoti classes ko thoda zyada importance) ----------
# Seedha inverse-frequency bahut extreme hota hai, isliye uska square-root liya hai
counts = torch.bincount(y_tr, minlength=n_classes).float()
weights = (counts.sum() / counts) ** 0.5
weights = weights * counts.sum() / (weights * counts).sum()  # average sample-weight = 1
print("\nClass weights:")
for n, w in zip(names, weights.tolist()):
    print(f"  {n:28s} {w:.3f}")

# ---------- 3. Model ----------
def block(i, o, p):
    return [nn.Linear(i, o), nn.BatchNorm1d(o), nn.ReLU(), nn.Dropout(p)]


model = nn.Sequential(
    *block(n_features, 256, 0.2),
    *block(256, 128, 0.2),
    *block(128, 64, 0.1),
    nn.Linear(64, n_classes),
).to(device)
print(f"\nParameters: {sum(p.numel() for p in model.parameters()):,}")

criterion = nn.CrossEntropyLoss(weight=weights.to(device))
optimizer = torch.optim.Adam(model.parameters(), lr=LR)
scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer, mode="max", factor=0.5, patience=2
)


def predict(X, bs=65536):
    model.eval()
    out = []
    with torch.no_grad():
        for i in range(0, len(X), bs):
            out.append(model(X[i : i + bs].to(device)).argmax(1).cpu())
    return torch.cat(out).numpy()


# ---------- 4. Training (best model val macro-F1 pe chuna jata hai, test pe nahi) ----------
best_f1, best_epoch = -1.0, 0
print("\nEpoch | train loss | val macro-F1 | time")
for epoch in range(1, EPOCHS + 1):
    model.train()
    t0 = time.time()
    perm = torch.randperm(len(X_tr))
    total = torch.zeros((), device=device)
    for i in range(0, len(perm), BATCH):
        idx = perm[i : i + BATCH]
        if len(idx) < 2:  # BatchNorm ko kam se kam 2 rows chahiye
            continue
        xb, yb = X_tr[idx].to(device), y_tr[idx].to(device)
        optimizer.zero_grad()
        loss = criterion(model(xb), yb)
        loss.backward()
        optimizer.step()
        total += loss.detach() * len(idx)
    train_loss = total.item() / len(X_tr)

    val_f1 = f1_score(y_val_np, predict(X_val), average="macro")
    scheduler.step(val_f1)
    mark = ""
    if val_f1 > best_f1:
        best_f1, best_epoch = val_f1, epoch
        torch.save(model.state_dict(), "models/mlp_best.pt")
        mark = "  <- best"
    print(f"{epoch:5d} | {train_loss:10.4f} | {val_f1:12.4f} | {time.time() - t0:4.0f}s{mark}")

print(f"\nBest val macro-F1: {best_f1:.4f} (epoch {best_epoch})")

# ---------- 5. Test (sirf ek baar, best model se) ----------
model.load_state_dict(torch.load("models/mlp_best.pt", map_location=device))
pred_te = predict(X_te)

test_f1 = f1_score(y_te_np, pred_te, average="macro")
test_acc = (pred_te == y_te_np).mean()
print(f"\nTest macro-F1 : {test_f1:.4f}")
print(f"Test accuracy : {test_acc:.4f}")
print(f"Random Forest : {RF_TEST_F1:.4f}  -> fark (MLP - RF): {test_f1 - RF_TEST_F1:+.4f}")

report = classification_report(y_te_np, pred_te, target_names=names, digits=4, zero_division=0)
print("\nPer-class report (test):\n", report)

p, r, f, _ = precision_recall_fscore_support(
    (y_te_np != 0).astype(int), (pred_te != 0).astype(int), average="binary", zero_division=0
)
print(f"Attack detect karna -> precision {p:.4f} | recall {r:.4f} | F1 {f:.4f}")

# ---------- 6. Confusion matrix ----------
cm = confusion_matrix(y_te_np, pred_te, normalize="true")
plt.figure(figsize=(12, 10))
sns.heatmap(cm, annot=True, fmt=".2f", xticklabels=names, yticklabels=names,
            cmap="Blues", cbar=False)
plt.xlabel("Model ne kya bola")
plt.ylabel("Asli class")
plt.title("MLP - confusion matrix (test, row-normalized)")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig(f"{FIG}/mlp_confusion_matrix.png", dpi=150)
plt.close()

# ---------- 7. Report save ----------
with open("reports/mlp_report.txt", "w", encoding="utf-8") as fh:
    fh.write(f"Best val macro-F1: {best_f1:.4f} (epoch {best_epoch})\n")
    fh.write(f"Test macro-F1: {test_f1:.4f}\nTest accuracy: {test_acc:.4f}\n")
    fh.write(f"Random Forest test macro-F1: {RF_TEST_F1:.4f}\n")
    fh.write(f"Attack-vs-benign: precision {p:.4f}, recall {r:.4f}, F1 {f:.4f}\n\n")
    fh.write(report)

print("\nSaved: models/mlp_best.pt, reports/mlp_report.txt, reports/figures/mlp_confusion_matrix.png")

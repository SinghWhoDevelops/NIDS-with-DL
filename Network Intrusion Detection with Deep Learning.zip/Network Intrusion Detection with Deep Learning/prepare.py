"""Step 3b: Clean data -> model-ready arrays.

Input : data/interim/cicids2017_clean.parquet   (clean.py ne banayi thi)
Output: data/processed/  (X/y train, val, test + scaler + label_map + feature_names)
"""
import json
import os

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

SRC = "data/interim/cicids2017_clean.parquet"
OUT = "data/processed"
SEED = 42
RARE = ["Heartbleed", "Infiltration", "Web Attack - Sql Injection"]
PLACEHOLDER_COLS = ["Init Fwd Win Bytes", "Init Bwd Win Bytes"]  # inme -1 = "value nahi mili"

os.makedirs(OUT, exist_ok=True)
df = pd.read_parquet(SRC)
print("Loaded:", df.shape)

# ---------- 1. Rare classes ko milao ----------
labels_present = set(df["Label"].unique())
missing = [c for c in RARE if c not in labels_present]
assert not missing, f"Ye labels nahi mile: {missing}\nAsli labels: {sorted(labels_present)}"
df["Label"] = df["Label"].replace({c: "Rare Attack" for c in RARE})

# ---------- 2. Label ko number banao (Benign hamesha 0) ----------
classes = ["Benign"] + sorted(c for c in df["Label"].unique() if c != "Benign")
label_map = {c: i for i, c in enumerate(classes)}
y = df["Label"].map(label_map)
assert y.notna().all(), "Kuch labels map nahi hue"
y = y.to_numpy(dtype=np.int64)
print("\nClasses:", label_map)

# ---------- 3. Features taiyar karo ----------
X = df.drop(columns="Label").astype(np.float32)
del df

# -1 wale columns: pehle ek "value nahi thi" flag banao, phir -1 ko 0 kar do
for c in PLACEHOLDER_COLS:
    if c in X.columns:
        X[c + " (no value)"] = (X[c] < 0).astype(np.float32)
        X[c] = X[c].clip(lower=0)

neg_cols = list(X.columns[X.min() < 0])
assert not neg_cols, f"In columns mein negative values bachi hain: {neg_cols}"

# log1p: bahut bade-chhote numbers (bytes, time) ko chhota/barabar karta hai
X = np.log1p(X)
feature_names = list(X.columns)
X = X.to_numpy(dtype=np.float32)
assert np.isfinite(X).all(), "Inf/NaN aa gaya, kuch gadbad hai"
print("Features:", X.shape[1])

# ---------- 4. Train / Val / Test split (70 / 15 / 15, stratified) ----------
X_tr, X_tmp, y_tr, y_tmp = train_test_split(
    X, y, test_size=0.30, stratify=y, random_state=SEED
)
X_val, X_te, y_val, y_te = train_test_split(
    X_tmp, y_tmp, test_size=0.50, stratify=y_tmp, random_state=SEED
)
del X, X_tmp

# ---------- 5. Scaling (scaler SIRF train pe fit hota hai) ----------
scaler = StandardScaler()
X_tr = scaler.fit_transform(X_tr).astype(np.float32)
X_val = scaler.transform(X_val).astype(np.float32)
X_te = scaler.transform(X_te).astype(np.float32)

# ---------- 6. Sanity check ----------
inv = {v: k for k, v in label_map.items()}
table = pd.DataFrame(
    {
        name: pd.Series(arr).value_counts().sort_index()
        for name, arr in [("train", y_tr), ("val", y_val), ("test", y_te)]
    }
).fillna(0).astype(int)
table.index = [inv[i] for i in table.index]
print("\nRows per class in each split:")
print(table)
print(f"\nShapes -> train {X_tr.shape}, val {X_val.shape}, test {X_te.shape}")
print(f"Train mean (0 ke paas hona chahiye): {X_tr.mean():.4f}")
print(f"Train std  (1 ke paas hona chahiye): {X_tr.std():.4f}")

# ---------- 7. Save ----------
for name, arr in [
    ("X_train", X_tr), ("y_train", y_tr),
    ("X_val", X_val), ("y_val", y_val),
    ("X_test", X_te), ("y_test", y_te),
]:
    np.save(f"{OUT}/{name}.npy", arr)

joblib.dump(scaler, f"{OUT}/scaler.joblib")
with open(f"{OUT}/label_map.json", "w") as f:
    json.dump(label_map, f, indent=2)
with open(f"{OUT}/feature_names.json", "w") as f:
    json.dump(feature_names, f, indent=2)

print(f"\nSaved everything in {OUT}/")

"""Step 4: Baseline model - Random Forest.

Deep learning model ko isi se compare karenge ("score to beat").
Input : data/processed/ (prepare.py ka output)
Output: reports/baseline_rf_report.txt, reports/figures/rf_confusion_matrix.png
"""
import json
import os
import time

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
)

D = "data/processed"
FIG = "reports/figures"
os.makedirs(FIG, exist_ok=True)
os.makedirs("reports", exist_ok=True)

# ---------- 1. Data load ----------
X_tr, y_tr = np.load(f"{D}/X_train.npy"), np.load(f"{D}/y_train.npy")
X_val, y_val = np.load(f"{D}/X_val.npy"), np.load(f"{D}/y_val.npy")
X_te, y_te = np.load(f"{D}/X_test.npy"), np.load(f"{D}/y_test.npy")

with open(f"{D}/label_map.json") as f:
    label_map = json.load(f)
with open(f"{D}/feature_names.json") as f:
    feature_names = json.load(f)
names = [k for k, _ in sorted(label_map.items(), key=lambda kv: kv[1])]

print("Train:", X_tr.shape, "| Val:", X_val.shape, "| Test:", X_te.shape)

# ---------- 2. Train ----------
print("\nTraining Random Forest (kuch minute lagenge, laptop ka fan tez chalega)...")
t0 = time.time()
rf = RandomForestClassifier(n_estimators=100, n_jobs=-1, random_state=42)
rf.fit(X_tr, y_tr)
print(f"Training time: {(time.time() - t0) / 60:.1f} min")

# ---------- 3. Predict ----------
pred_val = rf.predict(X_val)
pred_te = rf.predict(X_te)

val_f1 = f1_score(y_val, pred_val, average="macro")
test_f1 = f1_score(y_te, pred_te, average="macro")
test_acc = (pred_te == y_te).mean()
print(f"\nVal  macro-F1 : {val_f1:.4f}")
print(f"Test macro-F1 : {test_f1:.4f}")
print(f"Test accuracy : {test_acc:.4f}  (ispe zyada bharosa mat karna)")

# ---------- 4. Per-class report (test) ----------
report = classification_report(y_te, pred_te, target_names=names, digits=4, zero_division=0)
print("\nPer-class report (test):\n", report)

# ---------- 5. Attack vs Benign (IDS ke liye sabse zaroori) ----------
p, r, f, _ = precision_recall_fscore_support(
    (y_te != 0).astype(int), (pred_te != 0).astype(int), average="binary", zero_division=0
)
print(f"Attack detect karna -> precision {p:.4f} | recall {r:.4f} | F1 {f:.4f}")

# ---------- 6. Confusion matrix ----------
cm = confusion_matrix(y_te, pred_te, normalize="true")
plt.figure(figsize=(12, 10))
sns.heatmap(cm, annot=True, fmt=".2f", xticklabels=names, yticklabels=names,
            cmap="Blues", cbar=False)
plt.xlabel("Model ne kya bola")
plt.ylabel("Asli class")
plt.title("Random Forest - confusion matrix (test, row-normalized)")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig(f"{FIG}/rf_confusion_matrix.png", dpi=150)
plt.close()

# ---------- 7. Kaun se features important hain ----------
imp = pd.Series(rf.feature_importances_, index=feature_names).sort_values(ascending=False)
print("\nTop 15 important features:\n", imp.head(15).round(4))

# ---------- 8. Report save ----------
with open("reports/baseline_rf_report.txt", "w", encoding="utf-8") as fh:
    fh.write(f"Val macro-F1: {val_f1:.4f}\nTest macro-F1: {test_f1:.4f}\n")
    fh.write(f"Test accuracy: {test_acc:.4f}\n")
    fh.write(f"Attack-vs-benign: precision {p:.4f}, recall {r:.4f}, F1 {f:.4f}\n\n")
    fh.write(report)
    fh.write("\nTop 15 features:\n" + imp.head(15).round(4).to_string())

print("\nSaved: reports/baseline_rf_report.txt and reports/figures/rf_confusion_matrix.png")
